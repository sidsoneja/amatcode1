function (element, pass) {
   document.getElementById("login-form_password").value = pass;
   document.getElementById("signBtn").disabled = false;
	
	var buttons = document.getElementsByClassName('primary vdl-button vdl-button--primary');
for(var i = 0; i < buttons.length; i++){
    buttons[i].setAttribute('aria-disabled', 'false');
}



}




 

